"""Equivariant atom-coefficient model."""

from .compact_model import CompactCoefficientGNN, CompactModelConfig
from .mace_like_model import MaceLikeCoefficientGNN, MaceLikeModelConfig
from .model import EquivariantCoefficientGNN, ModelConfig


def build_compact_coefficient_model(config: dict):
    """Build the requested compact coefficient architecture."""

    values = dict(config)
    architecture = values.pop("architecture", "simple")
    if architecture == "simple":
        return CompactCoefficientGNN(CompactModelConfig(**values))
    if architecture == "mace_like":
        return MaceLikeCoefficientGNN(MaceLikeModelConfig(**values))
    raise ValueError(f"Unknown coefficient architecture: {architecture}")

__all__ = [
    "CompactCoefficientGNN",
    "CompactModelConfig",
    "MaceLikeCoefficientGNN",
    "MaceLikeModelConfig",
    "build_compact_coefficient_model",
    "EquivariantCoefficientGNN",
    "ModelConfig",
]
